public class StudentManagement {
    // TODO: khai bao thuoc tinh students la array chua cac doi tuong thuoc lop Student (max. 100)

    Student[] students = new Student[100];

    int preNum = 0;

    /**
     * .
     * documentation
     */
    public static boolean sameGroup(Student s1, Student s2) {
        // TODO:
        return s1.getGroup().equals(s2.getGroup());
    }

    /**
     * .
     * documentation
     */
    public void addStudent(Student newStudent) {
        // TODO:
        students[preNum++] = newStudent;

    }

    /**
     * .
     * documentation
     */
    public String studentsByGroup() {
        // TODO:
        StringBuilder information = new StringBuilder();
        for (int i = preNum - 1; i > 0; i--) {
            if (students[i].getGroup().compareTo(students[i].getGroup()) < 0) {
                Student temp = students[i];
                students[i] = students[i - 1];
                students[i - 1] = temp;
            }
        }

        for (int i = 0; i < preNum; i++) {
            if (i == 0 || !sameGroup(students[i], students[i - 1])) {
                information.append(students[i].getGroup()).append("\n");
            }
            information.append(students[i].getInfo()).append("\n");
        }
        return information.toString();
    }

    /**
     * .
     * documentation
     */
    public void removeStudent(String id) {
        // TODO:
        Student[] copy = new Student[100];
        int k = 0;
        for (int i = 0; i < preNum; i++) {
            if (!students[i].getId().equals(id)) {
                copy[k++] = students[i];
            }
        }
        students = copy.clone();
        preNum--;
    }

    /**
     * .
     * documentation
     */
    public static void main(String[] args) {
        /* documentation */

    }

}